export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyA77CMnccmWSuX-cgzFkT8RjPRQbeJJ25k",
    authDomain: "auth.booksnation.ca",
    databaseURL: "https://bookstore2july24.firebaseio.com",
    projectId: "bookstore2july24",
    storageBucket: "bookstore2july24.appspot.com",
    messagingSenderId: "581038020415"
  }
};
